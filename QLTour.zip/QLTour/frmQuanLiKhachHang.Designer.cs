﻿namespace QLTour
{
    partial class frmQuanLiKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label maKHLabel;
            System.Windows.Forms.Label tenKHLabel;
            System.Windows.Forms.Label ngSinhLabel;
            System.Windows.Forms.Label emailLabel;
            System.Windows.Forms.Label sDTKHLabel;
            System.Windows.Forms.Label dCKHLabel;
            System.Windows.Forms.Label maLoaiKHLabel;
            System.Windows.Forms.Label tenDoanhNghiepLabel;
            System.Windows.Forms.Label gioiTinhLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuanLiKhachHang));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.gioiTinhRadioButton = new System.Windows.Forms.RadioButton();
            this.kHACHHANGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qlTourDuLichDataSet = new QLTour.QlTourDuLichDataSet();
            this.maKHSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.tenKHTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.ngSinhDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.emailTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.sDTKHTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.dCKHTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.maLoaiKHSpinEdit = new DevExpress.XtraEditors.SpinEdit();
            this.tenDoanhNghiepTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton4 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton5 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton6 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton7 = new DevExpress.XtraEditors.SimpleButton();
            this.textEdit5 = new DevExpress.XtraEditors.TextEdit();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.btnOK = new DevExpress.XtraEditors.SimpleButton();
            this.textEdit4 = new DevExpress.XtraEditors.TextEdit();
            this.comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.label1 = new System.Windows.Forms.Label();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.kHACHHANGDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.simpleButton13 = new DevExpress.XtraEditors.SimpleButton();
            this.kHACHHANGTableAdapter = new QLTour.QlTourDuLichDataSetTableAdapters.KHACHHANGTableAdapter();
            this.tableAdapterManager = new QLTour.QlTourDuLichDataSetTableAdapters.TableAdapterManager();
            this.kHACHHANGBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.kHACHHANGBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            maKHLabel = new System.Windows.Forms.Label();
            tenKHLabel = new System.Windows.Forms.Label();
            ngSinhLabel = new System.Windows.Forms.Label();
            emailLabel = new System.Windows.Forms.Label();
            sDTKHLabel = new System.Windows.Forms.Label();
            dCKHLabel = new System.Windows.Forms.Label();
            maLoaiKHLabel = new System.Windows.Forms.Label();
            tenDoanhNghiepLabel = new System.Windows.Forms.Label();
            gioiTinhLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kHACHHANGBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qlTourDuLichDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maKHSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenKHTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngSinhDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngSinhDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDTKHTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dCKHTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maLoaiKHSpinEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenDoanhNghiepTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit5.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kHACHHANGDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kHACHHANGBindingNavigator)).BeginInit();
            this.kHACHHANGBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // maKHLabel
            // 
            maKHLabel.AutoSize = true;
            maKHLabel.Location = new System.Drawing.Point(41, 55);
            maKHLabel.Name = "maKHLabel";
            maKHLabel.Size = new System.Drawing.Size(41, 13);
            maKHLabel.TabIndex = 49;
            maKHLabel.Text = "Ma KH:";
            // 
            // tenKHLabel
            // 
            tenKHLabel.AutoSize = true;
            tenKHLabel.Location = new System.Drawing.Point(41, 81);
            tenKHLabel.Name = "tenKHLabel";
            tenKHLabel.Size = new System.Drawing.Size(45, 13);
            tenKHLabel.TabIndex = 51;
            tenKHLabel.Text = "Ten KH:";
            // 
            // ngSinhLabel
            // 
            ngSinhLabel.AutoSize = true;
            ngSinhLabel.Location = new System.Drawing.Point(41, 107);
            ngSinhLabel.Name = "ngSinhLabel";
            ngSinhLabel.Size = new System.Drawing.Size(47, 13);
            ngSinhLabel.TabIndex = 53;
            ngSinhLabel.Text = "Ng Sinh:";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Location = new System.Drawing.Point(41, 137);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new System.Drawing.Size(35, 13);
            emailLabel.TabIndex = 57;
            emailLabel.Text = "Email:";
            // 
            // sDTKHLabel
            // 
            sDTKHLabel.AutoSize = true;
            sDTKHLabel.Location = new System.Drawing.Point(400, 55);
            sDTKHLabel.Name = "sDTKHLabel";
            sDTKHLabel.Size = new System.Drawing.Size(43, 13);
            sDTKHLabel.TabIndex = 59;
            sDTKHLabel.Text = "SDTKH:";
            // 
            // dCKHLabel
            // 
            dCKHLabel.AutoSize = true;
            dCKHLabel.Location = new System.Drawing.Point(400, 81);
            dCKHLabel.Name = "dCKHLabel";
            dCKHLabel.Size = new System.Drawing.Size(38, 13);
            dCKHLabel.TabIndex = 61;
            dCKHLabel.Text = "DCKH:";
            // 
            // maLoaiKHLabel
            // 
            maLoaiKHLabel.AutoSize = true;
            maLoaiKHLabel.Location = new System.Drawing.Point(400, 107);
            maLoaiKHLabel.Name = "maLoaiKHLabel";
            maLoaiKHLabel.Size = new System.Drawing.Size(63, 13);
            maLoaiKHLabel.TabIndex = 63;
            maLoaiKHLabel.Text = "Ma Loai KH:";
            // 
            // tenDoanhNghiepLabel
            // 
            tenDoanhNghiepLabel.AutoSize = true;
            tenDoanhNghiepLabel.Location = new System.Drawing.Point(400, 133);
            tenDoanhNghiepLabel.Name = "tenDoanhNghiepLabel";
            tenDoanhNghiepLabel.Size = new System.Drawing.Size(99, 13);
            tenDoanhNghiepLabel.TabIndex = 65;
            tenDoanhNghiepLabel.Text = "Ten Doanh Nghiep:";
            // 
            // gioiTinhLabel
            // 
            gioiTinhLabel.AutoSize = true;
            gioiTinhLabel.Location = new System.Drawing.Point(41, 166);
            gioiTinhLabel.Name = "gioiTinhLabel";
            gioiTinhLabel.Size = new System.Drawing.Size(51, 13);
            gioiTinhLabel.TabIndex = 66;
            gioiTinhLabel.Text = "Gioi Tinh:";
            // 
            // groupControl2
            // 
            this.groupControl2.Appearance.BackColor = System.Drawing.Color.LightSteelBlue;
            this.groupControl2.Appearance.Options.UseBackColor = true;
            this.groupControl2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.groupControl2.Controls.Add(gioiTinhLabel);
            this.groupControl2.Controls.Add(this.gioiTinhRadioButton);
            this.groupControl2.Controls.Add(maKHLabel);
            this.groupControl2.Controls.Add(this.maKHSpinEdit);
            this.groupControl2.Controls.Add(tenKHLabel);
            this.groupControl2.Controls.Add(this.tenKHTextEdit);
            this.groupControl2.Controls.Add(ngSinhLabel);
            this.groupControl2.Controls.Add(this.ngSinhDateEdit);
            this.groupControl2.Controls.Add(emailLabel);
            this.groupControl2.Controls.Add(this.emailTextEdit);
            this.groupControl2.Controls.Add(sDTKHLabel);
            this.groupControl2.Controls.Add(this.sDTKHTextEdit);
            this.groupControl2.Controls.Add(dCKHLabel);
            this.groupControl2.Controls.Add(this.dCKHTextEdit);
            this.groupControl2.Controls.Add(maLoaiKHLabel);
            this.groupControl2.Controls.Add(this.maLoaiKHSpinEdit);
            this.groupControl2.Controls.Add(tenDoanhNghiepLabel);
            this.groupControl2.Controls.Add(this.tenDoanhNghiepTextEdit);
            this.groupControl2.Controls.Add(this.simpleButton1);
            this.groupControl2.Controls.Add(this.simpleButton3);
            this.groupControl2.Controls.Add(this.simpleButton4);
            this.groupControl2.Controls.Add(this.simpleButton5);
            this.groupControl2.Controls.Add(this.simpleButton6);
            this.groupControl2.Controls.Add(this.simpleButton7);
            this.groupControl2.Controls.Add(this.textEdit5);
            this.groupControl2.Location = new System.Drawing.Point(308, 51);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(664, 265);
            this.groupControl2.TabIndex = 14;
            this.groupControl2.Text = "groupControl2";
            // 
            // gioiTinhRadioButton
            // 
            this.gioiTinhRadioButton.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.kHACHHANGBindingSource, "GioiTinh", true));
            this.gioiTinhRadioButton.Location = new System.Drawing.Point(146, 160);
            this.gioiTinhRadioButton.Name = "gioiTinhRadioButton";
            this.gioiTinhRadioButton.Size = new System.Drawing.Size(104, 24);
            this.gioiTinhRadioButton.TabIndex = 67;
            this.gioiTinhRadioButton.TabStop = true;
            this.gioiTinhRadioButton.Text = "Nữ";
            this.gioiTinhRadioButton.UseVisualStyleBackColor = true;
            // 
            // kHACHHANGBindingSource
            // 
            this.kHACHHANGBindingSource.DataMember = "KHACHHANG";
            this.kHACHHANGBindingSource.DataSource = this.qlTourDuLichDataSet;
            // 
            // qlTourDuLichDataSet
            // 
            this.qlTourDuLichDataSet.DataSetName = "QlTourDuLichDataSet";
            this.qlTourDuLichDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // maKHSpinEdit
            // 
            this.maKHSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.kHACHHANGBindingSource, "MaKH", true));
            this.maKHSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maKHSpinEdit.Location = new System.Drawing.Point(146, 52);
            this.maKHSpinEdit.Name = "maKHSpinEdit";
            this.maKHSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maKHSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maKHSpinEdit.TabIndex = 50;
            // 
            // tenKHTextEdit
            // 
            this.tenKHTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.kHACHHANGBindingSource, "TenKH", true));
            this.tenKHTextEdit.Location = new System.Drawing.Point(146, 78);
            this.tenKHTextEdit.Name = "tenKHTextEdit";
            this.tenKHTextEdit.Size = new System.Drawing.Size(100, 20);
            this.tenKHTextEdit.TabIndex = 52;
            // 
            // ngSinhDateEdit
            // 
            this.ngSinhDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.kHACHHANGBindingSource, "NgSinh", true));
            this.ngSinhDateEdit.EditValue = null;
            this.ngSinhDateEdit.Location = new System.Drawing.Point(146, 104);
            this.ngSinhDateEdit.Name = "ngSinhDateEdit";
            this.ngSinhDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngSinhDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ngSinhDateEdit.Size = new System.Drawing.Size(100, 20);
            this.ngSinhDateEdit.TabIndex = 54;
            // 
            // emailTextEdit
            // 
            this.emailTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.kHACHHANGBindingSource, "Email", true));
            this.emailTextEdit.Location = new System.Drawing.Point(146, 134);
            this.emailTextEdit.Name = "emailTextEdit";
            this.emailTextEdit.Size = new System.Drawing.Size(100, 20);
            this.emailTextEdit.TabIndex = 58;
            // 
            // sDTKHTextEdit
            // 
            this.sDTKHTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.kHACHHANGBindingSource, "SDTKH", true));
            this.sDTKHTextEdit.Location = new System.Drawing.Point(505, 52);
            this.sDTKHTextEdit.Name = "sDTKHTextEdit";
            this.sDTKHTextEdit.Size = new System.Drawing.Size(100, 20);
            this.sDTKHTextEdit.TabIndex = 60;
            // 
            // dCKHTextEdit
            // 
            this.dCKHTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.kHACHHANGBindingSource, "DCKH", true));
            this.dCKHTextEdit.Location = new System.Drawing.Point(505, 78);
            this.dCKHTextEdit.Name = "dCKHTextEdit";
            this.dCKHTextEdit.Size = new System.Drawing.Size(100, 20);
            this.dCKHTextEdit.TabIndex = 62;
            // 
            // maLoaiKHSpinEdit
            // 
            this.maLoaiKHSpinEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.kHACHHANGBindingSource, "MaLoaiKH", true));
            this.maLoaiKHSpinEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.maLoaiKHSpinEdit.Location = new System.Drawing.Point(505, 104);
            this.maLoaiKHSpinEdit.Name = "maLoaiKHSpinEdit";
            this.maLoaiKHSpinEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.maLoaiKHSpinEdit.Size = new System.Drawing.Size(100, 20);
            this.maLoaiKHSpinEdit.TabIndex = 64;
            // 
            // tenDoanhNghiepTextEdit
            // 
            this.tenDoanhNghiepTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.kHACHHANGBindingSource, "TenDoanhNghiep", true));
            this.tenDoanhNghiepTextEdit.Location = new System.Drawing.Point(505, 130);
            this.tenDoanhNghiepTextEdit.Name = "tenDoanhNghiepTextEdit";
            this.tenDoanhNghiepTextEdit.Size = new System.Drawing.Size(100, 20);
            this.tenDoanhNghiepTextEdit.TabIndex = 66;
            // 
            // simpleButton1
            // 
            this.simpleButton1.BackgroundImage = global::QLTour.Properties.Resources.Blue;
            this.simpleButton1.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.simpleButton1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image")));
            this.simpleButton1.Location = new System.Drawing.Point(404, 209);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(92, 36);
            this.simpleButton1.TabIndex = 49;
            this.simpleButton1.Text = "Cancel";
            // 
            // simpleButton3
            // 
            this.simpleButton3.BackgroundImage = global::QLTour.Properties.Resources.images;
            this.simpleButton3.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.simpleButton3.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton3.ImageOptions.Image")));
            this.simpleButton3.Location = new System.Drawing.Point(306, 209);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(92, 36);
            this.simpleButton3.TabIndex = 48;
            this.simpleButton3.Text = "Save";
            // 
            // simpleButton4
            // 
            this.simpleButton4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("simpleButton4.BackgroundImage")));
            this.simpleButton4.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.simpleButton4.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton4.ImageOptions.Image")));
            this.simpleButton4.Location = new System.Drawing.Point(110, 209);
            this.simpleButton4.Name = "simpleButton4";
            this.simpleButton4.Size = new System.Drawing.Size(92, 36);
            this.simpleButton4.TabIndex = 47;
            this.simpleButton4.Text = "Edit";
            // 
            // simpleButton5
            // 
            this.simpleButton5.BackgroundImage = global::QLTour.Properties.Resources.images__1_;
            this.simpleButton5.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.simpleButton5.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton5.ImageOptions.Image")));
            this.simpleButton5.Location = new System.Drawing.Point(208, 209);
            this.simpleButton5.Name = "simpleButton5";
            this.simpleButton5.Size = new System.Drawing.Size(92, 36);
            this.simpleButton5.TabIndex = 46;
            this.simpleButton5.Text = "Delete";
            // 
            // simpleButton6
            // 
            this.simpleButton6.BackgroundImage = global::QLTour.Properties.Resources.yellow;
            this.simpleButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.simpleButton6.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.simpleButton6.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton6.ImageOptions.Image")));
            this.simpleButton6.Location = new System.Drawing.Point(12, 209);
            this.simpleButton6.Name = "simpleButton6";
            this.simpleButton6.Size = new System.Drawing.Size(92, 36);
            this.simpleButton6.TabIndex = 45;
            this.simpleButton6.Text = "Insert";
            // 
            // simpleButton7
            // 
            this.simpleButton7.BackgroundImage = global::QLTour.Properties.Resources.greeen;
            this.simpleButton7.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.simpleButton7.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton7.ImageOptions.Image")));
            this.simpleButton7.Location = new System.Drawing.Point(513, 209);
            this.simpleButton7.Name = "simpleButton7";
            this.simpleButton7.Size = new System.Drawing.Size(92, 36);
            this.simpleButton7.TabIndex = 44;
            this.simpleButton7.Text = "Refesh";
            // 
            // textEdit5
            // 
            this.textEdit5.EditValue = "Thong tin khach hang";
            this.textEdit5.Location = new System.Drawing.Point(0, 0);
            this.textEdit5.Name = "textEdit5";
            this.textEdit5.Properties.Appearance.BackColor = System.Drawing.Color.Maroon;
            this.textEdit5.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit5.Properties.Appearance.ForeColor = System.Drawing.Color.Lime;
            this.textEdit5.Properties.Appearance.Options.UseBackColor = true;
            this.textEdit5.Properties.Appearance.Options.UseFont = true;
            this.textEdit5.Properties.Appearance.Options.UseForeColor = true;
            this.textEdit5.Size = new System.Drawing.Size(644, 32);
            this.textEdit5.TabIndex = 24;
            // 
            // groupControl1
            // 
            this.groupControl1.Appearance.BackColor = System.Drawing.Color.LightSteelBlue;
            this.groupControl1.Appearance.Options.UseBackColor = true;
            this.groupControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.groupControl1.Controls.Add(this.simpleButton2);
            this.groupControl1.Controls.Add(this.btnOK);
            this.groupControl1.Controls.Add(this.textEdit4);
            this.groupControl1.Controls.Add(this.comboBoxEdit1);
            this.groupControl1.Controls.Add(this.labelControl11);
            this.groupControl1.Controls.Add(this.textEdit2);
            this.groupControl1.Controls.Add(this.labelControl8);
            this.groupControl1.Controls.Add(this.textEdit1);
            this.groupControl1.Controls.Add(this.labelControl7);
            this.groupControl1.Location = new System.Drawing.Point(12, 48);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(280, 263);
            this.groupControl1.TabIndex = 13;
            this.groupControl1.Text = "groupControl1";
            // 
            // simpleButton2
            // 
            this.simpleButton2.BackgroundImage = global::QLTour.Properties.Resources.Blue;
            this.simpleButton2.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.simpleButton2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton2.ImageOptions.Image")));
            this.simpleButton2.Location = new System.Drawing.Point(156, 170);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(92, 32);
            this.simpleButton2.TabIndex = 26;
            this.simpleButton2.Text = "Cancel";
            // 
            // btnOK
            // 
            this.btnOK.BackgroundImage = global::QLTour.Properties.Resources.greeen;
            this.btnOK.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.btnOK.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnOK.ImageOptions.Image")));
            this.btnOK.Location = new System.Drawing.Point(42, 170);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(92, 32);
            this.btnOK.TabIndex = 25;
            this.btnOK.Text = "Tim";
            // 
            // textEdit4
            // 
            this.textEdit4.EditValue = "Tim kiem";
            this.textEdit4.Location = new System.Drawing.Point(0, 0);
            this.textEdit4.Name = "textEdit4";
            this.textEdit4.Properties.Appearance.BackColor = System.Drawing.Color.Maroon;
            this.textEdit4.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit4.Properties.Appearance.ForeColor = System.Drawing.Color.Lime;
            this.textEdit4.Properties.Appearance.Options.UseBackColor = true;
            this.textEdit4.Properties.Appearance.Options.UseFont = true;
            this.textEdit4.Properties.Appearance.Options.UseForeColor = true;
            this.textEdit4.Size = new System.Drawing.Size(279, 32);
            this.textEdit4.TabIndex = 23;
            // 
            // comboBoxEdit1
            // 
            this.comboBoxEdit1.Location = new System.Drawing.Point(116, 117);
            this.comboBoxEdit1.Name = "comboBoxEdit1";
            this.comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit1.Size = new System.Drawing.Size(132, 20);
            this.comboBoxEdit1.TabIndex = 22;
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(17, 120);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(72, 13);
            this.labelControl11.TabIndex = 21;
            this.labelControl11.Text = "Ten phong ban";
            // 
            // textEdit2
            // 
            this.textEdit2.Location = new System.Drawing.Point(116, 81);
            this.textEdit2.Name = "textEdit2";
            this.textEdit2.Size = new System.Drawing.Size(132, 20);
            this.textEdit2.TabIndex = 8;
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(17, 84);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(64, 13);
            this.labelControl8.TabIndex = 7;
            this.labelControl8.Text = "Ma nhan vien";
            // 
            // textEdit1
            // 
            this.textEdit1.Location = new System.Drawing.Point(116, 47);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Size = new System.Drawing.Size(132, 20);
            this.textEdit1.TabIndex = 6;
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(17, 50);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(64, 13);
            this.labelControl7.TabIndex = 5;
            this.labelControl7.Text = "Ma nhan vien";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(344, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(261, 25);
            this.label1.TabIndex = 12;
            this.label1.Text = "DANH SACH KHACH HANG";
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.kHACHHANGDataGridView);
            this.groupControl3.Location = new System.Drawing.Point(14, 362);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(940, 222);
            this.groupControl3.TabIndex = 15;
            this.groupControl3.Text = "groupControl3";
            // 
            // kHACHHANGDataGridView
            // 
            this.kHACHHANGDataGridView.AutoGenerateColumns = false;
            this.kHACHHANGDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.kHACHHANGDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.kHACHHANGDataGridView.DataSource = this.kHACHHANGBindingSource;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(31)))), ((int)(((byte)(53)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.kHACHHANGDataGridView.DefaultCellStyle = dataGridViewCellStyle1;
            this.kHACHHANGDataGridView.Location = new System.Drawing.Point(17, 33);
            this.kHACHHANGDataGridView.Name = "kHACHHANGDataGridView";
            this.kHACHHANGDataGridView.Size = new System.Drawing.Size(918, 220);
            this.kHACHHANGDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "MaKH";
            this.dataGridViewTextBoxColumn1.HeaderText = "MaKH";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "TenKH";
            this.dataGridViewTextBoxColumn2.HeaderText = "TenKH";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "NgSinh";
            this.dataGridViewTextBoxColumn3.HeaderText = "NgSinh";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "GioiTinh";
            this.dataGridViewTextBoxColumn4.HeaderText = "GioiTinh";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn5.HeaderText = "Email";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "SDTKH";
            this.dataGridViewTextBoxColumn6.HeaderText = "SDTKH";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "DCKH";
            this.dataGridViewTextBoxColumn7.HeaderText = "DCKH";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "MaLoaiKH";
            this.dataGridViewTextBoxColumn8.HeaderText = "MaLoaiKH";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "TenDoanhNghiep";
            this.dataGridViewTextBoxColumn9.HeaderText = "TenDoanhNghiep";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // simpleButton13
            // 
            this.simpleButton13.BackgroundImage = global::QLTour.Properties.Resources.yellow;
            this.simpleButton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.simpleButton13.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.simpleButton13.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton13.ImageOptions.Image")));
            this.simpleButton13.Location = new System.Drawing.Point(862, 590);
            this.simpleButton13.Name = "simpleButton13";
            this.simpleButton13.Size = new System.Drawing.Size(92, 32);
            this.simpleButton13.TabIndex = 51;
            this.simpleButton13.Text = "Trở về";
            // 
            // kHACHHANGTableAdapter
            // 
            this.kHACHHANGTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CTPHIEUNHAP_TOURTableAdapter = null;
            this.tableAdapterManager.DIADANHTableAdapter = null;
            this.tableAdapterManager.DIADIEMTableAdapter = null;
            this.tableAdapterManager.HANHTRINHTableAdapter = null;
            this.tableAdapterManager.HOPDONGTableAdapter = null;
            this.tableAdapterManager.HUONGDANVIENTableAdapter = null;
            this.tableAdapterManager.KHACHHANGTableAdapter = this.kHACHHANGTableAdapter;
            this.tableAdapterManager.KHACHSANTableAdapter = null;
            this.tableAdapterManager.LOAIKHACHHANGTableAdapter = null;
            this.tableAdapterManager.LOAIKHACHSANTableAdapter = null;
            this.tableAdapterManager.LOAITOURTableAdapter = null;
            this.tableAdapterManager.MANHINHTableAdapter = null;
            this.tableAdapterManager.NGUOIDUNGTableAdapter = null;
            this.tableAdapterManager.NHOMNGUOIDUNGTableAdapter = null;
            this.tableAdapterManager.PHANQUYENTableAdapter = null;
            this.tableAdapterManager.PHIEUNHAPTOURTableAdapter = null;
            this.tableAdapterManager.QUANLINHOMNGUOIDUNGTableAdapter = null;
            this.tableAdapterManager.TOURTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = QLTour.QlTourDuLichDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // kHACHHANGBindingNavigator
            // 
            this.kHACHHANGBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.kHACHHANGBindingNavigator.BindingSource = this.kHACHHANGBindingSource;
            this.kHACHHANGBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.kHACHHANGBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.kHACHHANGBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.kHACHHANGBindingNavigatorSaveItem});
            this.kHACHHANGBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.kHACHHANGBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.kHACHHANGBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.kHACHHANGBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.kHACHHANGBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.kHACHHANGBindingNavigator.Name = "kHACHHANGBindingNavigator";
            this.kHACHHANGBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.kHACHHANGBindingNavigator.Size = new System.Drawing.Size(972, 25);
            this.kHACHHANGBindingNavigator.TabIndex = 52;
            this.kHACHHANGBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // kHACHHANGBindingNavigatorSaveItem
            // 
            this.kHACHHANGBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.kHACHHANGBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("kHACHHANGBindingNavigatorSaveItem.Image")));
            this.kHACHHANGBindingNavigatorSaveItem.Name = "kHACHHANGBindingNavigatorSaveItem";
            this.kHACHHANGBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.kHACHHANGBindingNavigatorSaveItem.Text = "Save Data";
            this.kHACHHANGBindingNavigatorSaveItem.Click += new System.EventHandler(this.kHACHHANGBindingNavigatorSaveItem_Click);
            // 
            // frmQuanLiKhachHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(972, 631);
            this.Controls.Add(this.kHACHHANGBindingNavigator);
            this.Controls.Add(this.simpleButton13);
            this.Controls.Add(this.groupControl3);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.label1);
            this.Name = "frmQuanLiKhachHang";
            this.Text = "frmQuanLiKhachHang";
            this.Load += new System.EventHandler(this.frmQuanLiKhachHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kHACHHANGBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qlTourDuLichDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maKHSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenKHTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngSinhDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngSinhDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emailTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sDTKHTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dCKHTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maLoaiKHSpinEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenDoanhNghiepTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit5.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kHACHHANGDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kHACHHANGBindingNavigator)).EndInit();
            this.kHACHHANGBindingNavigator.ResumeLayout(false);
            this.kHACHHANGBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.TextEdit textEdit5;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.TextEdit textEdit4;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit textEdit2;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private DevExpress.XtraEditors.SimpleButton simpleButton4;
        private DevExpress.XtraEditors.SimpleButton simpleButton5;
        private DevExpress.XtraEditors.SimpleButton simpleButton6;
        private DevExpress.XtraEditors.SimpleButton simpleButton7;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SimpleButton btnOK;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.SimpleButton simpleButton13;
        private QlTourDuLichDataSet qlTourDuLichDataSet;
        private System.Windows.Forms.BindingSource kHACHHANGBindingSource;
        private QlTourDuLichDataSetTableAdapters.KHACHHANGTableAdapter kHACHHANGTableAdapter;
        private QlTourDuLichDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator kHACHHANGBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton kHACHHANGBindingNavigatorSaveItem;
        private System.Windows.Forms.RadioButton gioiTinhRadioButton;
        private DevExpress.XtraEditors.SpinEdit maKHSpinEdit;
        private DevExpress.XtraEditors.TextEdit tenKHTextEdit;
        private DevExpress.XtraEditors.DateEdit ngSinhDateEdit;
        private DevExpress.XtraEditors.TextEdit emailTextEdit;
        private DevExpress.XtraEditors.TextEdit sDTKHTextEdit;
        private DevExpress.XtraEditors.TextEdit dCKHTextEdit;
        private DevExpress.XtraEditors.SpinEdit maLoaiKHSpinEdit;
        private DevExpress.XtraEditors.TextEdit tenDoanhNghiepTextEdit;
        private System.Windows.Forms.DataGridView kHACHHANGDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
    }
}