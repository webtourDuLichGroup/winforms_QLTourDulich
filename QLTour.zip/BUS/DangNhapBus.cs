﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO;


namespace BUS
{
    public class DangNhapBus
    {

        public static bool DangNhap(string tenDangNhap, string matKhau)
        {
            //QuanLiTourDuLichEntities thucThe = new QuanLiTourDuLichEntities();
            //var ketqua = from ac in thucThe.NGUOIDUNGs
            //             where ac.TENDANGNHAP == tenDangNhap && ac.MATKHAU == matKhau
            //             select ac;
            //return ketqua.Any();

            return true;
        }
    }
}
