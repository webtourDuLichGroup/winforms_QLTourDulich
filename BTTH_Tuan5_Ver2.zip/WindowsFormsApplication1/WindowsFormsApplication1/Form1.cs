﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LINQ;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        QLNV nv = new QLNV();
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboKhoa.DataSource = nv.LoadKhoa();
            cboKhoa.DisplayMember = "TenKhoa";
            cboKhoa.ValueMember = "MaKhoa";
            dgrSV.DataSource = nv.LoadSV();
            dgrDiem.DataSource = nv.LoadDiem();

            cboMH.DataSource = nv.LoadMH();
            cboMH.DisplayMember = "TenMH";
            cboMH.ValueMember = "MaMH";
            
           
            
        }
        public void TrangThaiTxt(bool b)
        {
            cboMH.Enabled = txtMaSV.Enabled = txtDiem.Enabled = b;
        }
        private void cboKhoa_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cboLop.DataSource = nv.LoadLop(int.Parse(cboKhoa.SelectedValue.ToString()));
            cboLop.DisplayMember = "TenLop";
            cboLop.ValueMember = "MaLop";
        }

        private void cboLop_SelectionChangeCommitted(object sender, EventArgs e)
        {
            dgrSV.DataSource = nv.LoadSV_Lop(int.Parse(cboLop.SelectedValue.ToString()));
        }

        private void dgrSV_SelectionChanged(object sender, EventArgs e)
        {
            dgrDiem.DataSource = nv.LoadDiem_SV(int.Parse(dgrSV.CurrentRow.Cells[0].Value.ToString()));
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            DIEM diem = new DIEM();
            diem.MaSV = int.Parse(txtMaSV.Text);
            diem.MaMH = int.Parse(cboMH.SelectedValue.ToString());
            diem.Diem1 =int.Parse( txtDiem.Text);
            
            if ((txtMaSV.Text == string.Empty) || (txtDiem.Text == string.Empty))
            {
                MessageBox.Show("Dữ liệu chưa đủ");
                txtMaSV.Focus();
            }
            //else
            //{
            //    if ((int.Parse(txtMaSV.Text) == masv) && (int.Parse(cboMH.SelectedValue.ToString()) == mamh))
            //    {
            //        MessageBox.Show("Sinh viên đã học môn này rồi bạn ơi");
            //    }
            //}


            nv.ThemDiem(diem);
            MessageBox.Show("Thành công rồi nhé! ");
            dgrDiem.DataSource = nv.LoadDiem();

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            //int masv = int.Parse();
            //nv.XoaDiem(masv);
            MessageBox.Show("Xóa thành công");
            dgrDiem.DataSource = nv.LoadDiem();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Chắc chắn chưa??", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
           if(r== DialogResult.Yes)
            {
                int masv = int.Parse(dgrSV.SelectedRows.ToString());
                nv.CapNhat(masv, int.Parse(txtDiem.Text));
                MessageBox.Show("Cập nhật thành công");
                dgrDiem.DataSource = nv.LoadDiem();

            }
        }

        private void dgrDiem_SelectionChanged(object sender, EventArgs e)
        {
            txtMaSV.Text = dgrSV.CurrentRow.Cells[0].Value.ToString();
            cboMH.Text = dgrSV.CurrentRow.Cells[1].Value.ToString();
            txtDiem.Text = dgrSV.CurrentRow.Cells[0].Value.ToString();
        }

        
    }
}
