﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ
{
   public class QLNV
    {
       DataClasses1DataContext qlsv = new DataClasses1DataContext();
       public List<KHOA> LoadKhoa()
       {
           return qlsv.KHOAs.Select(t => t).ToList<KHOA>();
       }
       public List<LOP> LoadLop(int pMaKhoa)
       {
           return qlsv.LOPs.Where(t => t.MaKhoa == pMaKhoa).Select(t => t).ToList<LOP>();
       }
       public List<SV> LoadSV()
       {
          // var Khoas = from kh in qlsv.KHOAs
          //             where kh.MaKhoa == pMaKh
          //             select new { kh.MaKhoa, kh.TenKhoa };
          //return Khoas.ToList<>();
           return qlsv.SVs.Select(t => t).ToList<SV>();
        }
       public List<SV> LoadSV_Lop(int pMaLop)
       {
           return qlsv.SVs.Where(t => t.MaLop == pMaLop).Select(t => t).ToList<SV>();
       }
       public List<DIEM> LoadDiem()
       {
           return qlsv.DIEMs.Select(t => t).ToList<DIEM>();
       }
       public List<DIEM> LoadDiem_SV(int pMaSV)
       {
           return qlsv.DIEMs.Where(t => t.MaSV == pMaSV).Select(t => t).ToList<DIEM>();
       }
       public List<MONHOC> LoadMH()
       {
           return qlsv.MONHOCs.Select(t => t).ToList<MONHOC>();
       }
       public void ThemDiem(DIEM diem)
       {
           qlsv.DIEMs.InsertOnSubmit(diem);
           qlsv.SubmitChanges();
       }
       public void XoaDiem(int pMaSV)
       {
           DIEM diem = qlsv.DIEMs.Where(d => d.MaSV == pMaSV).FirstOrDefault();
           if (diem != null)
           {
               qlsv.DIEMs.DeleteOnSubmit(diem);
               qlsv.SubmitChanges();
           }
       }
       public void CapNhat(int pMaSV,int pDiem)
       {
           DIEM diem = qlsv.DIEMs.Where(d => d.MaSV == pMaSV).FirstOrDefault();
           if (diem != null)
           {
               diem.Diem1 = pDiem;
               qlsv.SubmitChanges();
           }
       }
    }
}
